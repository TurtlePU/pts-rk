#!/usr/bin/env bash
# Apply only; no network access or GitHub changes.
set -euo pipefail
ROOT="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd)"
BASE='723cf2ec61c737ae82ba33d2e7db44f650122b0e'
[[ $# == 1 ]] || { echo 'Usage: bash prepare_local.sh /absolute/path/to/clean/pts-rk-checkout' >&2; exit 2; }
bash "$ROOT/publish.sh" --check-package
cd -- "$1"
[[ "$(git rev-parse --show-toplevel)" == "$PWD" ]] || { echo 'Pass the repository root.' >&2; exit 2; }
[[ -z "$(git status --porcelain)" ]] || { echo 'Refusing to alter a dirty checkout.' >&2; exit 1; }
[[ "$(git rev-parse HEAD)" == "$BASE" ]] || { echo "Expected inspected base $BASE; no changes made." >&2; exit 1; }
git apply --check "$ROOT/direct-r.patch"
git apply --index "$ROOT/direct-r.patch"
git diff --cached --check
python3 - "$ROOT" <<'PY'
import hashlib,json,sys
from pathlib import Path
root=Path(sys.argv[1]); manifest=json.loads((root/'manifest.json').read_text())
for name,expected in manifest['payload_sha256'].items():
    if hashlib.sha256(Path(name).read_bytes()).hexdigest()!=expected:
        raise SystemExit('Patched file mismatch: '+name)
print('Applied and staged exactly the package payload. No commit or network action performed.')
PY
