## Scope

Restructure the direct interpretation of Tarski--Mostowski--Robinson arithmetic R
around the existing PTSrk.Syntax, Typing.typ and Ranks.RankSorts. This is a DRAFT
proof-development contribution, not a completed formalization of Theorem 5.
No changes to the original PTS rules, no set model, and no answer-type
nontriviality/consistency assertion are included.

## Three reviewable parts

1. Native fuel-bounded evaluation and syntax-directed checking, with supplied
   successful-run proof scripts ending in the original typing judgment.
2. Split fixed codes/certificates, indexed arithmetic proofs, pure witness
   generators, first-order syntax, and explicit remaining contracts.
3. Separate concrete regressions/native arithmetic, build driver, and provenance.

The new closed-certificate path is inspired by the lab-owned
clayrat/pts-dependent-types snapshot 7e6282d. Its bidirectional kernel is not
substituted for the target calculus. Lambda domain annotations are retained.
The old constructor-producing tactic remains isolated for symbolic-index goals.

## Verification status

- **Rocq compilation: NOT performed.** The authoring container has no Rocq/Dune/
  OCaml toolchain and cannot resolve direct download hosts. All proof scripts,
  including the new checker soundness scripts, still need kernel checking.
- Twelve small independent Python object-code checks passed on the split generator
  declarations, plus two invalid-inequality regressions. They are NOT Rocq checks.
- A full independent run timed out at 240 seconds; no full-run success is claimed.
- Static module/definition checks and aggregate/series patch application checks
  are recorded in the accompanying package. They do not establish typability.

## Remaining proof obligations

`docs/DirectR-obligations.md` records uniform generator totality, arbitrary-arity
selector/table certificates, Good-based bounded cases, all-index typing and
ground faithfulness, and preservation of arbitrary first-order derivations.
`DirectRObligations.target_from_generator_contracts` explicitly takes the unproved
contracts as arguments; it is not a closed proof of Theorem 5.

Please keep this draft until the build and assumption audit succeed, and do not
mark Theorem 5 complete until its uniform contracts and deduction preservation
are actually proved.

## Build

```sh
bash tools/check-direct-r.sh
```

Base reviewed: 723cf2ec61c737ae82ba33d2e7db44f650122b0e.
