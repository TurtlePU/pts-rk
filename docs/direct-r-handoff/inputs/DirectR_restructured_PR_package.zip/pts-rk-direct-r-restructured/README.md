# Restructured DirectR PR package

This package supersedes DirectR_lab_reuse_PR_package.zip. Do not apply both.
Nothing has been pushed or opened remotely by preparing this archive.
The source is a compiler-unchecked work in progress; Theorem 5 is unfinished.

## Contents

- `payload/`: exact final files to add/modify in TurtlePU/pts-rk.
- `direct-r.patch`: aggregate ordinary `git apply` patch against the pinned base.
- `patches/`: the same changes split into three reviewable commits.
- `publish.sh`: validates package/account/fork, applies the three patches in a
  fresh retained checkout, then pushes a new branch and opens a DRAFT PR.
- `prepare_local.sh`: applies the aggregate patch to a clean supplied checkout;
  performs no network request, commit, push, fork, or PR operation.
- `PR_TITLE.txt`, `PR_BODY.md`: draft text; it explicitly discloses uncompiled code.
- `manifest.json`: checksums; `review/` contains independent checks and logs.

The native evaluator/checker is now present, rather than merely recommended.
Its proof scripts are still uncompiled. The old symbolic Ltac is retained only
for inductive proof-family scripts, separately from native closed checking.

## Fast, exact publication path (Git/gh/Python 3 required)

First read `payload/docs/DirectR.md`, especially its limitations. Then:

```sh
gh auth login --hostname github.com --git-protocol https --web
test "$(gh api user --jq .login)" = akuklev
bash publish.sh --check-package
bash publish.sh
```

The last command creates or validates akuklev/pts-rk, makes three commits on a
new `direct-r-interpretation-restructured` branch, pushes that branch, and opens
an upstream draft PR. It does NOT run Rocq or claim a green build. It does NOT
merge, force-push, change either main branch, or overwrite an existing branch.
Its Git credential helper uses gh without printing/storing tokens in URLs.

For an existing branch name, set `DIRECT_R_BRANCH` to another unused name.
An existing non-fork repository named akuklev/pts-rk causes a hard error.
If upstream advanced, the script keeps the inspected base and warns; it does
not pretend to have rebased/retested the contribution against new source.

## Manual path with a build before publication

Set PKG to this extracted directory and use a NEW local checkout:

```sh
PKG="$(pwd)"
gh auth login --hostname github.com --git-protocol https --web
test "$(gh api user --jq .login)" = akuklev
gh auth setup-git --hostname github.com
gh repo fork TurtlePU/pts-rk --clone=false --remote=false
# Run the next command outside any existing pts-rk checkout.
git clone https://github.com/akuklev/pts-rk.git pts-rk-direct-r
cd pts-rk-direct-r
git remote add upstream https://github.com/TurtlePU/pts-rk.git
git fetch upstream main
git switch -c direct-r-interpretation-restructured 723cf2ec61c737ae82ba33d2e7db44f650122b0e
# Use the same existing Rocq/Equations switch as upstream.
dune build theories/Ranks.vo
bash "$PKG/prepare_local.sh" "$PWD"
git diff --cached --stat
git diff --cached --check
bash tools/check-direct-r.sh
# Inspect the results. Even on success, the uniform theorem is still open.
git commit -m "Restructure direct R interpretation and native checking draft"
git push --set-upstream origin direct-r-interpretation-restructured
gh pr create --repo TurtlePU/pts-rk --base main \
  --head akuklev:direct-r-interpretation-restructured --draft \
  --title "$(cat "$PKG/PR_TITLE.txt")" --body-file "$PKG/PR_BODY.md"
```

Configure your Git author name/email beforehand when using the manual path.
Do not commit or report a successful build unless it actually ran successfully.
A failing build may still be shared as a WIP draft, with its log and limitation
explicit; retain the PR body's uncompiled status until you update it accurately.
`prepare_local.sh` refuses a dirty working tree or a different base commit.

## Checks included

```sh
bash publish.sh --check-package
python3 review/checks/audit_structure.py
DIRECTR_CHECK_MODE=quick python3 review/checks/evaluate_rocq_generators.py
# Optional, potentially very expensive and timed out in the recorded attempt:
DIRECTR_CHECK_MODE=full python3 review/checks/evaluate_rocq_generators.py
```

The quick generator check evaluates a restricted pure source subset using a
Python interpreter. It does not execute Proof/Qed, Ltac, the new native checker,
or Rocq. Do not interpret its success as the uniform generator proof.
