#!/usr/bin/env python3
"""Independent beta-only PTS-rk checker for object-code sanity checks.

Only sorts, dependent products, annotated lambdas, application, and beta
conversion are used. Sort axiom: rk_i : rk_0.
Product rule: (rk_m, rk_n, rk_max(m+1,n)).

This small experimental checker is a reproducible sanity check, not a
proof-assistant formalization. It does not validate any Rocq proof script.
Python 3.10+, standard library only.
"""
from __future__ import annotations
from functools import lru_cache
from itertools import count
import argparse
import json
import time
import sys

sys.setrecursionlimit(20000)
Term = tuple
_counter = count()

def V(name: str) -> Term:
    return ('v', name)

def Rk(i: int) -> Term:
    if i < 0:
        raise ValueError('negative rank')
    return ('s', i)

def bind(tag: str, hint: str, ty: Term, body) -> Term:
    name = f'{hint}_{next(_counter)}'
    return (tag, name, ty, body(V(name)))

def lam(hint: str, ty: Term, body) -> Term:
    return bind('l', hint, ty, body)

def pi(hint: str, ty: Term, body) -> Term:
    return bind('p', hint, ty, body)

def app(f: Term, *args: Term) -> Term:
    for a in args:
        f = ('a', f, a)
    return f

def arrow(*types: Term) -> Term:
    if len(types) < 2:
        raise ValueError('arrow requires a domain and codomain')
    out = types[-1]
    for dom in reversed(types[:-1]):
        tail = out
        out = pi('_', dom, lambda _, tail=tail: tail)
    return out

@lru_cache(maxsize=300000)
def fv(t: Term) -> frozenset[str]:
    tag = t[0]
    if tag == 'v': return frozenset([t[1]])
    if tag == 's': return frozenset()
    if tag == 'a': return fv(t[1]) | fv(t[2])
    return fv(t[2]) | (fv(t[3]) - {t[1]})

@lru_cache(maxsize=300000)
def subst(t: Term, var: str, val: Term) -> Term:
    if var not in fv(t):
        return t
    tag = t[0]
    if tag == 'v': return val if t[1] == var else t
    if tag == 's': return t
    if tag == 'a': return ('a', subst(t[1], var, val), subst(t[2], var, val))
    name, ty, body = t[1:]
    newty = subst(ty, var, val)
    if name == var:
        return (tag, name, newty, body)
    if name in fv(val):
        newname = f'fresh_{next(_counter)}'
        body = subst(body, name, V(newname))
        name = newname
    return (tag, name, newty, subst(body, var, val))

@lru_cache(maxsize=300000)
def whnf(t: Term) -> Term:
    if t[0] != 'a':
        return t
    f = whnf(t[1])
    if f[0] == 'l':
        return whnf(subst(f[3], f[1], t[2]))
    return ('a', f, t[2])

@lru_cache(maxsize=300000)
def nf(t: Term) -> Term:
    t = whnf(t)
    tag = t[0]
    if tag in ('v', 's'): return t
    if tag == 'a': return ('a', nf(t[1]), nf(t[2]))
    return (tag, t[1], nf(t[2]), nf(t[3]))

def alpha(t: Term, u: Term, tenv=None, uenv=None) -> bool:
    tenv = {} if tenv is None else tenv
    uenv = {} if uenv is None else uenv
    if t[0] != u[0]: return False
    tag = t[0]
    if tag == 's': return t[1] == u[1]
    if tag == 'v':
        tv, uv = tenv.get(t[1]), uenv.get(u[1])
        return (t[1] == u[1]) if tv is None and uv is None else tv == uv
    if tag == 'a':
        return alpha(t[1], u[1], tenv, uenv) and alpha(t[2], u[2], tenv, uenv)
    if not alpha(t[2], u[2], tenv, uenv): return False
    depth = len(tenv)
    return alpha(t[3], u[3], {**tenv, t[1]: depth}, {**uenv, u[1]: depth})

def conv(t: Term, u: Term) -> bool:
    return alpha(nf(t), nf(u))

def pretty(t: Term) -> str:
    tag = t[0]
    if tag == 'v': return t[1]
    if tag == 's': return f'rk{t[1]}'
    if tag == 'a': return f'({pretty(t[1])} {pretty(t[2])})'
    op = 'lambda' if tag == 'l' else 'Pi'
    return f'({op} {t[1]}:{pretty(t[2])}. {pretty(t[3])})'

def infer(t: Term, ctx: dict[str, Term] | None = None) -> Term:
    ctx = {} if ctx is None else ctx
    tag = t[0]
    if tag == 's': return Rk(0)
    if tag == 'v':
        if t[1] not in ctx:
            raise TypeError(f'unbound variable {t[1]}')
        return ctx[t[1]]
    if tag in ('p', 'l'):
        name, dom, body = t[1:]
        domsort = whnf(infer(dom, ctx))
        if domsort[0] != 's':
            raise TypeError(f'domain is not a type: {pretty(dom)}')
        bodyty = infer(body, {**ctx, name: dom})
        if tag == 'l':
            bodysort = whnf(infer(bodyty, {**ctx, name: dom}))
            if bodysort[0] != 's':
                raise TypeError('lambda codomain has no sort')
            return ('p', name, dom, bodyty)
        codsort = whnf(bodyty)
        if codsort[0] != 's':
            raise TypeError(f'product codomain is not a type: {pretty(body)}')
        return Rk(max(domsort[1] + 1, codsort[1]))
    if tag == 'a':
        fty = whnf(infer(t[1], ctx))
        if fty[0] != 'p':
            raise TypeError(f'nonfunction in application: {pretty(fty)}')
        aty = infer(t[2], ctx)
        if not conv(aty, fty[2]):
            raise TypeError('argument mismatch:\nactual ' + pretty(nf(aty)) +
                            '\nexpected ' + pretty(nf(fty[2])))
        return subst(fty[3], fty[1], t[2])
    raise ValueError(f'unknown term {tag}')

def check(t: Term, ty: Term) -> None:
    if not conv(infer(t), ty):
        raise TypeError('incorrect whole-term type')


def clear_caches():
    for fun in (fv, subst, whnf, nf):
        fun.cache_clear()
