#!/usr/bin/env python3
"""Independent model checks for the Named.v-inspired arrow assembler.

This executes Python models of old fresh-binder assembly and new explicit-arrow
assembly, not Gallina, Ltac, or the Rocq kernel. It checks preservation of the
assembled de Bruijn syntax, including failure on free names. No typing theorem
is inferred from these tests.
"""
from pathlib import Path
import json, random


def shift(t, cutoff=0):
    tag = t[0]
    if tag == 's': return t
    if tag == 'v': return ('v', t[1] + (t[1] >= cutoff))
    if tag == 'a': return ('a', shift(t[1], cutoff), shift(t[2], cutoff))
    return (tag, shift(t[1], cutoff), shift(t[2], cutoff+1))


def mx(t):
    tag=t[0]
    if tag in ('s','closed'): return 0
    if tag=='v': return t[1]
    if tag in ('a','arrow'): return max(mx(t[1]),mx(t[2]))
    return max(t[1],mx(t[2]),mx(t[3]))


def lower(t):
    tag=t[0]
    if tag in ('s','v','closed'): return t
    if tag=='arrow':
        a,b=lower(t[1]),lower(t[2])
        return ('p',mx(b)+1,a,b)
    if tag=='a': return ('a',lower(t[1]),lower(t[2]))
    return (tag,t[1],lower(t[2]),lower(t[3]))


def assemble(t,env):
    tag=t[0]
    if tag=='s': return t
    if tag=='closed': return t[1]
    if tag=='v':
        try: return ('v',env.index(t[1]))
        except ValueError: return None
    if tag in ('a','arrow'):
        a,b=assemble(t[1],env),assemble(t[2],env)
        if a is None or b is None: return None
        return ('a',a,b) if tag=='a' else ('p',a,shift(b))
    a,b=assemble(t[2],env),assemble(t[3],[t[1]]+env)
    if a is None or b is None: return None
    return (tag,a,b)


rng=random.Random(20261012)
names=[0,1,2,3,7,100,1000]
closed=[('s',0),('p',('s',0),('v',0)),('l',('s',0),('v',0))]

def term(depth):
    if depth==0:
        k=rng.randrange(3)
        return ('s',rng.randrange(6)) if k==0 else (('v',rng.choice(names)) if k==1 else ('closed',rng.choice(closed)))
    k=rng.randrange(6)
    if k<2:return term(0)
    if k<4:return (['a','arrow'][k-2],term(depth-1),term(depth-1))
    return (['p','l'][k-4],rng.choice(names),term(depth-1),term(depth-1))


def main():
    n=12000; good=bad=0
    for i in range(n):
        env=[rng.choice(names) for _ in range(rng.randrange(7))]
        t=('arrow',term(rng.randrange(4)),term(rng.randrange(5)))
        new=assemble(t,env); old=assemble(lower(t),env)
        assert new==old,(i,env,t,new,old)
        if new is None:bad+=1
        else:good+=1
    assert assemble(('arrow',('s',0),('v',7)),[7])==('p',('s',0),('v',1))
    assert assemble(('arrow',('s',0),('v',7)),[]) is None
    # A codomain binder shadows an outer variable; the new arrow itself does not.
    t=('arrow',('s',0),('l',7,('s',0),('v',7)))
    assert assemble(t,[7])==('p',('s',0),('l',('s',0),('v',0)))
    result={'status':'passed','random_seed':20261012,'old_new_comparisons':n,
            'successful_assembly_cases':good,'unbound_name_cases':bad,
            'explicit_regressions':3,'rocq_compilation':False,
            'scope':'Independent Python assembler models, not a Rocq proof or execution.'}
    Path(__file__).with_name('arrow_checks.json').write_text(json.dumps(result,indent=2)+'\n')
    print(json.dumps(result,indent=2))

if __name__=='__main__':main()
