#!/usr/bin/env python3
"""Static source/module audit, NOT a Rocq parser or kernel check."""
from pathlib import Path
import re, json, hashlib, sys
ROOT=Path(__file__).resolve().parents[2]
TH=ROOT/'payload/theories'

def strip_comments(s):
    out=[]; i=0; depth=0; quoted=False
    while i<len(s):
        if not quoted and s.startswith('(*',i): depth+=1; i+=2
        elif depth and s.startswith('*)',i): depth-=1; i+=2
        elif depth:i+=1
        elif s[i]=='"':
            out.append(s[i]);i+=1
            if quoted and i<len(s) and s[i]=='"':out.append(s[i]);i+=1
            else:quoted=not quoted
        else:out.append(s[i]);i+=1
    assert depth==0 and not quoted,'Unclosed comment or string'
    return ''.join(out)
def normalized(s):return re.sub(r'\s+','',strip_comments(s))
def mod(s,name):
    a=s.index('Module '+name+'.');b=s.index('End '+name+'.',a)+len('End '+name+'.')
    return s[a:b]
def fingerprint(s):return hashlib.sha256(normalized(s).encode()).hexdigest()

def extracted_sections(files):
    g=mod(files['DirectRGenerated'],'Generated')
    return {
      'Codes':mod(files['DirectRCodes'],'Codes'),
      'Generated':g,
      'FirstOrder':mod(files['DirectRFirstOrder'],'FirstOrder'),
      'ArithmeticCore':mod(files['DirectRArithmetic'],'ArithmeticCore'),
      'CappedArithmetic':mod(files['DirectRArithmetic'],'CappedArithmetic'),
    }

def main():
    files={p.stem:p.read_text() for p in TH.glob('*.v')}
    originals={'Syntax','AbstractRewriting','Congruence','Reduction','Confluence','DefEq','Context','Typing','Inversions','Preservation','SN','Ranks'}
    graph={}
    for name,text in files.items():
        clean=strip_comments(text)
        assert not re.search(r'(?m)^\s*(?:Axiom|Axioms|Parameter|Parameters|Conjecture|Admitted)\b',clean), name
        assert not re.search(r'\badmit\b',clean), name
        deps=set()
        for m in re.finditer(r'From\s+PTSrk\s+Require\s+(?:Import|Export)\s+([^.]*)\.',clean):
            deps.update(m.group(1).split())
        assert deps <= originals|files.keys(), (name, deps-(originals|files.keys()))
        graph[name]=deps&files.keys()
    order=[]; pending=dict(graph)
    while pending:
        ready=sorted(k for k,v in pending.items() if not (v&pending.keys()))
        assert ready,'Module dependency cycle'
        for name in ready:order.append(name);del pending[name]
    dune=(TH/'dune').read_text();ml=re.search(r'\(modules\s+([^)]*)\)',dune).group(1).split()
    assert len(ml)==len(set(ml)) and set(ml)==originals|files.keys(),'Dune module mismatch'
    assert 'DirectRTests' not in graph['DirectR'] and 'DirectRArithmetic' not in graph['DirectR']
    assert 'RkCheck.certify_with 4096' in files['DirectRProofs']
    assert 'RkCheck.certify_with 65536' in files['DirectRTests']
    expected=json.loads((ROOT/'review/unchanged_sections.json').read_text())
    actual={k:fingerprint(v) for k,v in extracted_sections(files).items()}
    assert actual==expected,('Mathematical definitions/generators changed',actual,expected)
    result={'static_audit':'passed','scope':'not Rocq compilation',
      'module_count':len(files),'topological_order':order,
      'unchanged_normalized_sections':sorted(actual),
      'explicit_admissions_or_new_axioms':False}
    (ROOT/'review/structure_checks.json').write_text(json.dumps(result,indent=2)+'\n')
    print(json.dumps(result,indent=2))
if __name__=='__main__':main()
