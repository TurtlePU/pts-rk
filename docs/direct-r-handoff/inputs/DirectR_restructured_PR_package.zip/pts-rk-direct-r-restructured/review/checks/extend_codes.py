from build_codes import *
import textwrap

# Universal object-level witness for every observation field except the
# four domain fields, whose witnesses are already in the input file.
ADDITIONAL=[]
SYMS={}
for lname, ident, ty in laws[4:]:
    tail=ty; objs=[]
    while tail[0]=='p' and tail[2]==X:
        x=tail[1];g=tail[3][1]
        assert tail[3][2]==de(V(x))
        objs.append((x,g)); tail=tail[3][3]
    hyps=[]
    # Relation inputs have rank two: in the syntax an arrow into a negative
    # relation has a product as domain. The final relation has raw-code domain.
    while tail[0]=='p' and tail[2][0]=='p':
        hyps.append((tail[1],tail[2]));tail=tail[3]
    # Replace observation objects by outer arithmetic presentations; the
    # telescope binds 0..122, so use 200.. instead of its original identifiers.
    env={x:V(200+2*i) for i,(x,g) in enumerate(objs)}
    def globalize(t):
        if t==B:return B
        if t[0]=='v':return env.get(t[1],t)
        if t[0]=='s':return t
        if t[0]=='a':
            f=t;args=[]
            while f[0]=='a':args.append(f[2]);f=f[1]
            args.reverse()
            if f==rel:
                return ap(E,*map(globalize,args)) # caller is negative relation
            if f==ordr:return ap(O,*map(globalize,args))
            if f==s:return ap(Succ,*map(globalize,args))
            if f==ad:return ap(Add,*map(globalize,args))
            if f==mu:return ap(Mul,*map(globalize,args))
            return ap(globalize(f),*map(globalize,args))
        if t[0]=='p' and t[3]==B and t[2][0]=='a':
            f=t[2]
            while f[0]=='a':f=f[1]
            if f in (rel,ordr):return globalize(t[2])
        if t==z:return Z
        return (t[0],t[1],globalize(t[2]),globalize(t[3]))
    # z replacement has to precede the variable case.
    oldglobalize=globalize
    def globalize(t, rec=oldglobalize):
        if t==z:return Z
        return rec(t)
    fields=[]; args=[]
    for i,(x,g) in enumerate(objs):
        d=V(200+2*i);gd=V(201+2*i)
        fields.extend([(200+2*i,D),(201+2*i,ap(G,d))])
        args.extend([fold(d),ap(gd,*obs_args)])
    for i,(h,hA) in enumerate(hyps):
        fields.append((300+i,globalize(hA)))
        args.append(ap(V(300+i),*obs_args))
    p=lams(fields+obs_fields,ap(V(ident),*args))
    expected=pis(fields,globalize(tail))
    cname='nLaw_'+lname; SYMS[lname]=p
    ADDITIONAL.append((cname,p,expected))

# Keep the previous named constants and the telescope spelling as shared nodes.
KNOWN={t:name for name,t in CODE_DEFS}
KNOWN[('obs-marker',)]=True
for i in range(2,9):KNOWN[jf(i)]=f'nJ{i}'
chunks=[]
for name,t,ty in ADDITIONAL:
    a=textwrap.fill(pp(t,KNOWN),100,initial_indent='  ',subsequent_indent='  ',break_long_words=False,break_on_hyphens=False)
    b=textwrap.fill(pp(ty,KNOWN),100,initial_indent='  ',subsequent_indent='  ',break_long_words=False,break_on_hyphens=False)
    chunks.append(f'Definition {name} : named :=\n{a}.\nDefinition {name}Type : named :=\n{b}.\nDefinition {name[1:]} : closed_term := close {name} eq_refl.\nDefinition {name[1:]}Type : closed_term := close {name}Type eq_refl.\n')
    KNOWN[t]=name
if __name__=='__main__':
    Path(__file__).with_name('additional_codes.vpart').write_text('\n'.join(chunks))
    import pts_checker as ck
    for name,t,ty in ADDITIONAL:
        print(name,flush=True)
        ck.check(to_old(t),to_old(ty));ck.clear_caches()
    print('All additional fields type-checked independently (not Rocq).')
