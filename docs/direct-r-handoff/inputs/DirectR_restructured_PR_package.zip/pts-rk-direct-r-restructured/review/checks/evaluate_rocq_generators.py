#!/usr/bin/env python3
"""Evaluate the pure term-generator subset of DirectR.v, then PTS-type-check.

This is NOT a Rocq interpreter or proof checker. Only the explicitly supported
pure Definition/Fixpoint expressions in Generated and Kernel are evaluated;
no Lemma/Theorem/Proof/Qed, Ltac, typing proof, or logical-core proof is run.
This checks the actual generator expressions, rather than a hand-written
second implementation. A Rocq build remains necessary for kernel validation.
"""
from __future__ import annotations
from dataclasses import dataclass
from pathlib import Path
import re,sys,json,time,os
sys.path.insert(0,str(Path(__file__).parent))
import extend_codes as base
import pts_checker as ck
sys.setrecursionlimit(30000)

@dataclass(frozen=True)
class Con:
    name:str
    args:tuple=()

constructors={'Some':1,'None':0,'true':0,'false':0,'ox':1,'oz':0,'os':1,'oa':2,'om':2,'aeq':0,'ale':0,'law':3,'ax_add':2,'ax_mul':2,'ax_distinct':3,'ax_bounded':1,'ax_comparison':1,'S':1}

def curry(f,n):
    if n==0:return f()
    def step(args):
        return lambda a: f(*(args+(a,))) if len(args)+1==n else step(args+(a,))
    return step(())

class Parser:
    def __init__(self,s):
        self.ts=re.findall(r'=>|:=|\+\+|::|->|\|\||&&|<=|<>|[A-Za-z_][A-Za-z0-9_\'.]*|[0-9]+|[^\s]',s)
        self.i=0
    def peek(self):return self.ts[self.i] if self.i<len(self.ts) else '<eof>'
    def pop(self,t=None):
        r=self.peek();self.i+=1
        if t is not None and r!=t:raise SyntaxError(f'expected {t}, got {r}: {self.ts[max(0,self.i-8):self.i+8]}')
        return r
    def pattern_atom(self):
        t=self.pop()
        if t=="'":return self.pattern_atom()
        if t=='(':
            p=self.pattern()
            self.pop(')');return p
        if t=='[':self.pop(']');return ('nil',)
        if t.isdigit():return ('num',int(t))
        if t in constructors:
            return ('con',t,tuple(self.pattern_atom() for _ in range(constructors[t])))
        return ('var',t)
    def pattern_cons(self):
        p=self.pattern_atom()
        if self.peek()=='::':self.pop();return ('cons',p,self.pattern_cons())
        return p
    def pattern(self):
        ps=[self.pattern_cons()]
        while self.peek()==',':self.pop();ps.append(self.pattern_cons())
        return ps[0] if len(ps)==1 else ('tuple',tuple(ps))
    def expr(self):
        t=self.peek()
        if t=='fun':
            self.pop();ns=[]
            while self.peek()!='=>':
                if self.peek()=='(':
                    self.pop();g=[]
                    while self.peek() not in (':',')'):g.append(self.pop())
                    if self.peek()==':':
                        while self.peek()!=')':self.pop()
                    self.pop(')');ns+=g
                else:ns.append(self.pop())
            self.pop('=>');return ('lambda',ns,self.expr())
        if t=='let':
            self.pop();p=self.pattern();self.pop(':=');v=self.expr();self.pop('in');return ('let',p,v,self.expr())
        if t=='if':
            self.pop();c=self.expr();self.pop('then');a=self.expr();self.pop('else');return ('if',c,a,self.expr())
        if t=='match':
            self.pop();vs=[self.expr()]
            while self.peek()==',':self.pop();vs.append(self.expr())
            self.pop('with');branches=[]
            while self.peek()!='end':
                if self.peek()=='|':self.pop()
                p=self.pattern();self.pop('=>');b=self.expr();branches.append((p,b))
            self.pop('end');return ('match',vs,branches)
        return self.binexpr(0)
    prec={'::':1,'++':2,'+':3,'*':4}
    def binexpr(self,level):
        if level==5:return self.application()
        a=self.binexpr(level+1)
        while self.peek() in self.prec and self.prec[self.peek()]==level:
            op=self.pop();b=self.binexpr(level if op=='::' else level+1);a=('bin',op,a,b)
        return a
    def application(self):
        a=self.atom()
        while self.peek() not in ('<eof>',')',']',';',',','=>','in','with','then','else','|','end') and self.peek() not in self.prec:
            a=('app',a,self.atom())
        return a
    def atom(self):
        t=self.pop()
        if t=='(':
            es=[self.expr()]
            while self.peek()==',':self.pop();es.append(self.expr())
            self.pop(')');return es[0] if len(es)==1 else ('tuple',es)
        if t=='[':
            es=[]
            if self.peek()!=']':
                es.append(self.expr())
                while self.peek()==';':self.pop();es.append(self.expr())
            self.pop(']');return ('list',es)
        if t.isdigit():return ('num',int(t))
        if t=='true':return ('bool',True)
        if t=='false':return ('bool',False)
        if re.fullmatch(r'[A-Za-z_][A-Za-z0-9_\'.]*',t):return ('name',t)
        raise SyntaxError(f'unexpected token {t}, near {self.ts[max(0,self.i-8):self.i+8]}')
    def all(self):
        a=self.expr()
        if self.peek()!='<eof>':raise SyntaxError(f'left over {self.ts[self.i:]}')
        return a

def pat(p,v):
    t=p[0]
    if t=='var':return {} if p[1]=='_' else {p[1]:v}
    if t=='num':return {} if v==p[1] else None
    if t=='nil':return {} if v==[] else None
    if t=='tuple':
        if not isinstance(v,tuple) or len(v)!=len(p[1]):return None
        parts=[pat(x,y) for x,y in zip(p[1],v)]
    elif t=='cons':
        if not isinstance(v,list) or not v:return None
        parts=[pat(p[1],v[0]),pat(p[2],v[1:])]
    elif t=='con':
        name,args=p[1:]
        if name=='true':return {} if v is True else None
        if name=='false':return {} if v is False else None
        if name=='S':return pat(args[0],v-1) if isinstance(v,int) and v>0 else None
        if not isinstance(v,Con) or name!=v.name:return None
        parts=[pat(x,y) for x,y in zip(args,v.args)]
    else:raise RuntimeError(p)
    if any(x is None for x in parts):return None
    out={}
    for x in parts:out.update(x)
    return out

class Interpreter:
    def __init__(self):self.env={};self.declarations=[]
    def eval(self,a,local):
        k=a[0]
        if k in ('num','bool'):return a[1]
        if k=='name':
            if a[1] in local:return local[a[1]]
            if a[1] in self.env:return self.env[a[1]]
            raise NameError(a[1])
        if k=='app':
            f=self.eval(a[1],local);v=self.eval(a[2],local)
            if not callable(f):raise TypeError(f'noncallable {f!r}; AST={a[1]!r}')
            return f(v)
        if k=='list':return [self.eval(x,local) for x in a[1]]
        if k=='tuple':return tuple(self.eval(x,local) for x in a[1])
        if k=='lambda':
            ns,b=a[1:]
            return curry(lambda *args:self.eval(b,{**local,**dict(zip(ns,args))}),len(ns))
        if k=='let':
            p,v,b=a[1:];v=self.eval(v,local);m=pat(p,v)
            if m is None:raise ValueError('let pattern failure')
            return self.eval(b,{**local,**m})
        if k=='if':return self.eval(a[2] if self.eval(a[1],local) else a[3],local)
        if k=='bin':
            op,x,y=a[1:];x=self.eval(x,local);y=self.eval(y,local)
            if op=='::':return [x]+y
            if op in ('+','++'):return x+y
            if op=='*':return x*y
        if k=='match':
            values=[self.eval(x,local) for x in a[1]];v=values[0] if len(values)==1 else tuple(values)
            for p,b in a[2]:
                m=pat(p,v)
                if m is not None:return self.eval(b,{**local,**m})
            raise ValueError(f'no branch for {v}')
        raise ValueError(a)
    def declare(self,s,prefix=''):
        s=s.strip();head,body=s.split(':=',1)
        head=re.sub(r'\{struct\s+\w+\}','',head)
        toks=re.findall(r'[A-Za-z_][A-Za-z0-9_\']*|[():{}]',head)
        assert toks.pop(0) in ('Definition','Fixpoint')
        name=toks.pop(0);args=[];i=0
        while i<len(toks):
            t=toks[i]
            if t==':':break
            if t in ('(','{'):
                end=')' if t=='(' else '}';i+=1
                while toks[i] not in (':',end):args.append(toks[i]);i+=1
                depth=1
                while depth:
                    if toks[i]==t:depth+=1
                    elif toks[i]==end:depth-=1
                    i+=1
            else:args.append(t);i+=1
        body=body.strip()
        if body.endswith('.'):body=body[:-1]
        try:a=Parser(body).all()
        except Exception as e:raise SyntaxError(f'in {name}: {e}') from e
        f=curry(lambda *vals:self.eval(a,dict(zip(args,vals))),len(args))
        self.env[prefix+name]=f;self.declarations.append(name)
    def load(self,src,prefix='',skip=()):
        src=re.sub(r'\(\*.*?\*\)','',src,flags=re.S)
        # Top-level Definition/Fixpoint commands end at . immediately followed by newline.
        for m in re.finditer(r'^(Definition|Fixpoint)\s+(\w+)\b[\s\S]*?\.\s*$',src,re.M):
            if m[2] in skip:continue
            self.declare(m[0],prefix)


def make_env(src):
    it=Interpreter();E=it.env
    E['S']=lambda n:n+1
    for con,n in constructors.items():
        if con=='S':continue
        E[con]=curry(lambda *a,name=con:Con(name,a),n)
    E['true'],E['false']=True,False
    E.update({k:curry(v,n) for k,(v,n) in {
       'Nat.max':(max,2),'Nat.min':(min,2),'Nat.eqb':(lambda a,b:a==b,2),
       'Nat.leb':(lambda a,b:a<=b,2),'seq':(lambda a,n:list(range(a,a+n)),2),
       'map':(lambda f,xs:[f(x) for x in xs],2),'nth':(lambda n,xs,d:xs[n] if n<len(xs) else d,3),
       'fold_right':(lambda f,z,xs:foldr(f,z,xs),3),
       'fold_left':(lambda f,xs,z:foldl(f,xs,z),3),
       'app':(lambda f,x:base.ap(f,x),2),
       'fst':(lambda p:p[0],1),'snd':(lambda p:p[1],1),
       'NVar':(base.V,1),'NSort':(base.U,1),'NApp':(base.ap,2),
       'NPi':(base.P,3),'NLam':(base.L,3),'NClosed':(lambda t:t,1),
       'nArrow':(base.ar,2),'napps':(lambda f,xs:base.ap(f,*xs),2)
    }.items()})
    codes={'Bottom':base.B,'Top':base.Top,'top_proof':base.Id,'Domain':base.D,'zero':base.Z,
       'successor':base.Succ,'addition':base.Add,'multiplication':base.Mul,'Good':base.Good,
       'Equality':base.E,'Order':base.O,'G':base.G,'g_zero_proof':base.Gz,'g_succ_proof':base.Gs,
       'g_add_proof':base.Ga,'g_mul_proof':base.Gm,'good_zero_proof':base.goodZ,
       'good_succ_proof':base.goodS,'good_to_g_proof':base.GoodG,'nTop':base.Top,
       'nJ2':base.jf(2)}
    for name,t,_ in base.ADDITIONAL:codes[name[1:]]=t
    E.update(codes)
    E['numeral']=base.nm
    def nselector(q,i):return base.lams([(k,base.U(1)) for k in range(q)],base.V(i))
    def nselectorT(q):return base.ars(*([base.U(1)]*(q+1)))
    E['nSelector']=curry(nselector,2)
    def fdata(K):
        q=K+2;c=K+1;F=nselectorT(q);u,v=base.V(q),base.V(q+1)
        fields=[(i,base.U(1)) for i in range(q)]
        un=base.L(q,F,base.lams(fields,base.ap(u,*[base.V(min(i+1,c)) for i in range(q)])))
        def binary(fn):return base.lams([(q,F),(q+1,F)]+fields,
          base.ap(u,*[base.ap(v,*[base.V(fn(i,j)) for j in range(q)]) for i in range(q)]))
        def rel(fn):return base.lams([(q,F),(q+1,F)],
          base.ap(u,*[base.ap(v,*[(base.B if fn(i,j) else base.Top) for j in range(q)]) for i in range(q)]))
        Q=base.V(q+1)
        de=base.L(q,F,base.P(q+1,base.ar(F,base.U(3)),
          base.ars(*([base.ap(Q,nselector(q,i)) for i in range(q)]+[base.ap(Q,u)]))))
        return [F,nselector(q,0),un,binary(lambda i,j:min(i+j,c)),binary(lambda i,j:min(i*j,c)),de,rel(lambda i,j:i==j),rel(lambda i,j:i<=j)]
    E['nCappedObservationData']=fdata
    E['arity']=lambda l:l.args[0]
    E['premises']=lambda l:l.args[1]
    E['conclusion']=lambda l:l.args[2]
    # First evaluate the actual pure witness definitions in the Kernel module.
    kernel=src.split('Module Kernel.',1)[1].split('End Kernel.',1)[0]
    segment=kernel.split('Definition apps ',1)[1].split('Lemma ground_order_typed',1)[0]
    segment='Definition apps '+segment
    # Aliases are loaded without a prefix so recursive calls refer to the same definitions.
    it.load(segment)
    for nm in it.declarations[:]:E['Kernel.'+nm]=E[nm]
    # Then evaluate exactly the pure generator declarations in the .v file.
    gen=src.split('Module Generated.',1)[1].split('End Generated.',1)[0].split('Ltac realize_instance',1)[0]
    gen=gen.split('Definition B :=',1)[1]
    gen=gen.split('\n',1)[1]
    # Type synonyms have no runtime part. The executable witness wrapper [assemble]
    # is omitted: closedness and the actual named terms are independently checked.
    it.load(gen,skip=('atom','witness'))
    return it

def foldr(f,z,xs):
    for x in reversed(xs):z=f(x)(z)
    return z

def foldl(f,xs,z):
    for x in xs:z=f(z)(x)
    return z

def apply(f,*xs):
    for x in xs:f=f(x)
    return f

if __name__=='__main__':
    root=Path(__file__).resolve().parents[2]
    src='\n'.join((root/'payload'/'theories'/name).read_text() for name in
      ['DirectRCodes.v', 'DirectRProofs.v', 'DirectRGenerated.v'])
    it=make_env(src);E=it.env
    print('Parsed executable declarations:',len(it.declarations),flush=True)
    tests=[]
    quick = os.environ.get('DIRECTR_CHECK_MODE', 'quick') != 'full'
    quick_labels = {
        'G(numeral 0)', 'G(numeral 1)', 'G(numeral 2)', 'G(numeral 4)',
        'R1(0,0)', 'R2(0,0)', 'R1(1,2)', 'R2(1,2)',
        'order(0,0)', 'order(0,1)', 'R3(1,0)', 'R3(0,1)'
    }
    def check(label,t,ty):
        if quick and label not in quick_labels:
            return
        assert not base.fv(t),(label,'free variables',base.fv(t))
        t0=time.time();ck.check(base.to_old(t),base.to_old(ty));ck.clear_caches()
        tests.append({'name':label,'closed':True,'independent_pts_typing':'passed','seconds':round(time.time()-t0,4)})
        print(label,'OK',tests[-1]['seconds'],flush=True)
    for n in [0,1,2,4]:
        check(f'G(numeral {n})',apply(E['Kernel.observed_numeral'],n),base.ap(base.G,base.nm(n)))
    for m,n in [(0,0),(1,2),(2,1),(2,2),(3,2)]:
        check(f'R1({m},{n})',apply(E['Kernel.ground_add_proof'],m,n),base.ap(base.E,base.ap(base.Add,base.nm(m),base.nm(n)),base.nm(m+n)))
        check(f'R2({m},{n})',apply(E['Kernel.ground_mul_proof'],m,n),base.ap(base.E,base.ap(base.Mul,base.nm(m),base.nm(n)),base.nm(m*n)))
    for m,n in [(0,0),(0,1),(1,2),(1,4)]:
        check(f'order({m},{n})',apply(E['Kernel.ground_order_proof'],m,n),base.ap(base.O,base.nm(m),base.nm(n)))
    for K in [0,1]:
        fields=apply(E['observation_arguments'],K)
        dfields=[apply(f,2000) for f in fields]
        # Substitution under each law is performed by the named checker itself:
        # apply one complete observation to the global reflexivity proof.
        p=base.ap(base.Er,base.Z,base.Gz,*dfields)
        ty=base.ar(base.ap(dfields[6],dfields[1],dfields[1]),base.B)
        check(f'all 23 observation certificates K={K}',p,ty)
    for n in [0,1]:
        p=apply(E['run'],apply(E['bounded_cases'],n))
        ty=base.P(20,base.D,base.ar(base.ap(base.Good,base.V(20)),base.ncase(n,base.V(20))))
        check(f'bounded_cases({n})',p,ty)
        p=apply(E['run'],apply(E['axiom_bounded'],n))
        ty=base.P(20,base.D,base.ars(base.ap(base.Good,base.V(20)),base.ap(base.O,base.V(20),base.nm(n)),base.nds([base.ap(base.E,base.V(20),base.nm(i)) for i in range(n+1)])))
        check(f'R4({n})',p,ty)
        p=apply(E['run'],apply(E['axiom_comparison'],n))
        ty=base.P(20,base.D,base.ar(base.ap(base.Good,base.V(20)),base.nds([base.ap(base.O,base.V(20),base.nm(n)),base.ap(base.O,base.nm(n),base.V(20))])))
        check(f'R5({n})',p,ty)
    for m,n in [(1,0),(0,1),(2,1)]:
        p=apply(E['run'],apply(E['refute_eq'],m,n))
        check(f'R3({m},{n})',p,base.ar(base.ap(base.E,base.nm(m),base.nm(n)),base.B))
    # Bad external premises produce an unbound name, not a fabricated proof.
    for m,n in [(0,0),(1,1)]:
        p=apply(E['run'],apply(E['refute_eq'],m,n))
        assert base.fv(p)==frozenset([0])
    report={'status':'passed','scope':'executed actual pure generator expressions, NOT Rocq/Ltac compilation',
            'declarations_parsed':len(it.declarations),'mode':'quick' if quick else 'full','checks':tests,'invalid_inequality_indices_rejected':2}
    (root/'review'/'checks'/'generator_checks.json').write_text(json.dumps(report,indent=2))
