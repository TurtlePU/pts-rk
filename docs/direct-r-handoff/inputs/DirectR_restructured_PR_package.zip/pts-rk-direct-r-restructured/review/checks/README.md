# Independent checks, not Rocq builds

`generator_checks.json` and `generator_quick.log` record the completed
12-case quick run (plus rejection of two invalid inequality indices).
`generator_run.log` is an incomplete FULL attempt terminated by a 240-second
command timeout; its partial output is retained, not reported as a pass.

`evaluate_rocq_generators.py` reads DirectRCodes.v, DirectRProofs.v and
DirectRGenerated.v. It evaluates only its supported pure generator subset;
it does NOT execute proof scripts or the newly introduced Gallina checker.
Other Python files provide independent named assembly and beta typing models.

`audit_structure.py` checks preserved section fingerprints, imports, acyclicity,
and obvious explicit axiom/admission commands. It is not a Coq parser.
The new native checker still needs to be compiled and tested in Rocq.
