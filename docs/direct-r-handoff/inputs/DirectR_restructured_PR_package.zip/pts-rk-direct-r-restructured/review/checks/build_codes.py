#!/usr/bin/env python3
"""Generate named object-language expressions for DirectR.v.
This is a construction/sanity-check script, not a Rocq verifier.
"""
from __future__ import annotations
from functools import lru_cache
from pathlib import Path
import importlib.util, json, sys

# A small named *assembler* for the existing PTSrk.Syntax.Term datatype.
# p/l bind numerical identifiers.  Fresh nondependent products are hygienic.
def U(i): return ('s',i)
def V(i): return ('v',i)
def P(i,a,b): return ('p',i,a,b)
def L(i,a,b): return ('l',i,a,b)
def ap(f,*xs):
    for x in xs: f=('a',f,x)
    return f
@lru_cache(None)
def mx(t):
    if t[0]=='s': return 0
    if t[0]=='v': return t[1]
    if t[0]=='a': return max(mx(t[1]),mx(t[2]))
    return max(t[1],mx(t[2]),mx(t[3]))
def ar(a,b): return P(mx(b)+1,a,b)
def ars(*xs):
    t=xs[-1]
    for a in reversed(xs[:-1]): t=ar(a,t)
    return t
def pis(fields,b):
    for i,a in reversed(fields): b=P(i,a,b)
    return b
def lams(fields,b):
    for i,a in reversed(fields): b=L(i,a,b)
    return b

B=P(0,U(0),V(0))
Top=ar(U(0),U(0))
Id=L(0,U(0),V(0))
X,z,s,ad,mu,delta,rel,ordr=map(V,range(8))
base_fields=[(0,U(1)),(1,X),(2,ar(X,X)),(3,ars(X,X,X)),(4,ars(X,X,X))]
D=P(0,U(1),ars(X,ar(X,X),ars(X,X,X),ars(X,X,X),X))
Z=lams(base_fields,z)
def fold(d):return ap(d,X,z,s,ad,mu)
Succ=L(20,D,lams(base_fields,ap(s,fold(V(20)))))
Add=lams([(20,D),(21,D)]+base_fields,ap(ad,fold(V(20)),fold(V(21))))
Mul=lams([(20,D),(21,D)]+base_fields,ap(mu,fold(V(20)),fold(V(21))))
Q=V(40)
stepS=pis([(30,D)],ar(ap(Q,V(30)),ap(Q,ap(Succ,V(30)))))
def stepB(op):
    return pis([(30,D),(31,D)],ars(ap(Q,V(30)),ap(Q,V(31)),ap(Q,ap(op,V(30),V(31)))))
good_fields=[(40,ar(D,U(10))),(42,ap(Q,Z)),(43,stepS),(44,stepB(Add)),(45,stepB(Mul))]
Good=L(20,D,pis(good_fields,ap(Q,V(20))))
goodZ=lams(good_fields,V(42))
gargs=list(map(V,[40,42,43,44,45]))
goodS=lams([(20,D),(22,ap(Good,V(20)))]+good_fields,
           ap(V(43),V(20),ap(V(22),*gargs)))
def goodBinary(op,q):
    return lams([(20,D),(21,D),(22,ap(Good,V(20))),(23,ap(Good,V(21)))]+good_fields,
                ap(V(q),V(20),V(21),ap(V(22),*gargs),ap(V(23),*gargs)))

params=base_fields+[(5,ar(X,U(4))),(6,ars(X,X,U(1))),(7,ars(X,X,U(1)))]
def de(t):return ap(delta,t)
def eq(t,u):return ar(ap(rel,t,u),B)
def le(t,u):return ar(ap(ordr,t,u),B)
def guard(ids,body):
    f=[]
    for i in ids:f.extend([(i,X),(1000+i,de(V(i)))])
    return pis(f,body)
u,v,w,up,vp=map(V,[30,31,32,33,34])
laws=[
 ('dom_zero',100,de(z)),
 ('dom_succ',101,guard([30],de(ap(s,u)))),
 ('dom_add',102,guard([30,31],de(ap(ad,u,v)))),
 ('dom_mul',103,guard([30,31],de(ap(mu,u,v)))),
 ('eq_refl',104,guard([30],eq(u,u))),
 ('eq_sym',105,guard([30,31],ar(eq(u,v),eq(v,u)))),
 ('eq_trans',106,guard([30,31,32],ars(eq(u,v),eq(v,w),eq(u,w)))),
 ('succ_congr',107,guard([30,31],ar(eq(u,v),eq(ap(s,u),ap(s,v))))),
 ('add_congr',108,guard([30,33,31,34],ars(eq(u,up),eq(v,vp),eq(ap(ad,u,v),ap(ad,up,vp))))),
 ('mul_congr',109,guard([30,33,31,34],ars(eq(u,up),eq(v,vp),eq(ap(mu,u,v),ap(mu,up,vp))))),
 ('order_congr',110,guard([30,33,31,34],ars(eq(u,up),eq(v,vp),le(u,v),le(up,vp)))),
 ('order_refl',111,guard([30],le(u,u))),
 ('order_trans',112,guard([30,31,32],ars(le(u,v),le(v,w),le(u,w)))),
 ('add_zero',113,guard([30],eq(ap(ad,z,u),u))),
 ('add_succ',114,guard([30,31],eq(ap(ad,ap(s,u),v),ap(s,ap(ad,u,v))))),
 ('mul_zero',115,guard([30],eq(ap(mu,z,u),z))),
 ('mul_succ',116,guard([30,31],eq(ap(mu,ap(s,u),v),ap(ad,v,ap(mu,u,v))))),
 ('mul_zero_right',117,guard([30],eq(ap(mu,u,z),z))),
 ('le_succ',118,guard([30],le(u,ap(s,u)))),
 ('le_add_left',119,guard([30,31],le(u,ap(ad,u,v)))),
 ('le_add_right',120,guard([30,31],le(v,ap(ad,u,v)))),
 ('le_mul_left',121,guard([30,31],ar(le(ap(s,z),v),le(u,ap(mu,u,v))))),
 ('le_mul_right',122,guard([30,31],ar(le(ap(s,z),u),le(v,ap(mu,u,v)))))
]
obs_fields=params+[(i,t) for name,i,t in laws]
obs_args=[V(i) for i,_ in obs_fields]
E=lams([(20,D),(21,D)],pis(obs_fields,eq(fold(V(20)),fold(V(21)))))
O=lams([(20,D),(21,D)],pis(obs_fields,le(fold(V(20)),fold(V(21)))))
G=L(20,D,pis(obs_fields,de(fold(V(20)))))
Gz=lams(obs_fields,V(100))
Gs=lams([(20,D),(22,ap(G,V(20)))]+obs_fields,
        ap(V(101),fold(V(20)),ap(V(22),*obs_args)))
def Gbinary(op,i):
    return lams([(20,D),(21,D),(22,ap(G,V(20))),(23,ap(G,V(21)))]+obs_fields,
                ap(V(i),fold(V(20)),ap(V(22),*obs_args),fold(V(21)),ap(V(23),*obs_args)))
# Important: all observation object binders are individually delta-guarded.
Er=lams([(20,D),(22,ap(G,V(20)))]+obs_fields,
        ap(V(104),fold(V(20)),ap(V(22),*obs_args)))
Or=lams([(20,D),(22,ap(G,V(20)))]+obs_fields,
        ap(V(111),fold(V(20)),ap(V(22),*obs_args)))

def jf(k):
    assert k>=1
    if k==1:return Top
    a=jf(k-1);return ar(a,a)
def ji(k):
    if k==1:return Id
    return L(50,jf(k-1),V(50))
# Good -> G via the exact-rank lift J9 -> G.
Motive=L(30,D,ar(jf(9),ap(G,V(30))))
H0=L(50,jf(9),Gz)
Hs=lams([(30,D),(51,ap(Motive,V(30))),(50,jf(9))],ap(Gs,V(30),ap(V(51),ji(9))))
def hb(op,gop):
    return lams([(30,D),(31,D),(51,ap(Motive,V(30))),(52,ap(Motive,V(31))),(50,jf(9))],
                 ap(gop,V(30),V(31),ap(V(51),ji(9)),ap(V(52),ji(9))))
Ga,Gm=Gbinary(Add,102),Gbinary(Mul,103)
GoodG=lams([(20,D),(22,ap(Good,V(20)))],ap(V(22),Motive,H0,Hs,hb(Add,Ga),hb(Mul,Gm),ji(9)))

def nm(n):
    a=Z
    for _ in range(n): a=ap(Succ,a)
    return a

def nds(items):
    return ars(*([ar(a,B) for a in items]+[B]))
def ncase(n,d):return nds([ap(E,d,nm(i)) for i in range(n+1)]+[ap(O,nm(n+1),d)])
def ninv(n,d):return P(41,U(8),ar(ars(ap(G,d),ncase(n,d),V(41)),V(41)))

CODE_DEFS=[('nBottom',B),('nTop',Top),('nTopProof',Id),('nDomain',D),('nZero',Z),
 ('nSucc',Succ),('nAdd',Add),('nMul',Mul),('nGood',Good),('nGoodZero',goodZ),
 ('nGoodSucc',goodS),('nGoodAdd',goodBinary(Add,44)),('nGoodMul',goodBinary(Mul,45)),
 ('nEquality',E),('nOrder',O),('nAdmittedObservations',G),('nGZero',Gz),('nGSucc',Gs),
 ('nGAdd',Ga),('nGMul',Gm),('nEqRefl',Er),('nOrderRefl',Or),('nJ9',jf(9)),('nj9',ji(9)),
 ('nGoodToG',GoodG)]
EXPECTED=[U(1),U(1),Top,U(3),D,ar(D,D),ars(D,D,D),ars(D,D,D),ar(D,U(12)),ap(Good,Z),
 pis([(20,D)],ar(ap(Good,V(20)),ap(Good,ap(Succ,V(20))))),
 pis([(20,D),(21,D)],ars(ap(Good,V(20)),ap(Good,V(21)),ap(Good,ap(Add,V(20),V(21))))),
 pis([(20,D),(21,D)],ars(ap(Good,V(20)),ap(Good,V(21)),ap(Good,ap(Mul,V(20),V(21))))),
 ars(D,D,U(6)),ars(D,D,U(6)),ar(D,U(6)),ap(G,Z),
 pis([(20,D)],ar(ap(G,V(20)),ap(G,ap(Succ,V(20))))),
 pis([(20,D),(21,D)],ars(ap(G,V(20)),ap(G,V(21)),ap(G,ap(Add,V(20),V(21))))),
 pis([(20,D),(21,D)],ars(ap(G,V(20)),ap(G,V(21)),ap(G,ap(Mul,V(20),V(21))))),
 pis([(20,D)],ar(ap(G,V(20)),ap(E,V(20),V(20)))),
 pis([(20,D)],ar(ap(G,V(20)),ap(O,V(20),V(20)))),U(9),jf(9),
 pis([(20,D)],ar(ap(Good,V(20)),ap(G,V(20))))]

@lru_cache(None)
def fv(t):
    if t[0]=='v':return frozenset([t[1]])
    if t[0]=='s':return frozenset()
    if t[0]=='a':return fv(t[1])|fv(t[2])
    return fv(t[2]) | (fv(t[3])-{t[1]})

# Pretty printer recognizes previously defined closed fragments, so the output
# is readable rather than containing repeated thousands of syntax nodes.
def pp(t, known):
    if t in known:return known[t]
    # Share the full observation telescope in types and witnesses.
    if known.get(('obs-marker',)):
        for tag,fn in [('p','nAllObs'),('l','nAbstractObs')]:
            tail=t
            for ident,typ in obs_fields:
                if tail[0]!=tag or tail[1]!=ident or tail[2]!=typ: break
                tail=tail[3]
            else:
                return '('+fn+' '+pp(tail,known)+')'
    tag=t[0]
    if tag=='s':return f'(NSort {t[1]})'
    if tag=='v':return f'(NVar {t[1]})'
    if tag=='a':
        args=[];f=t
        while f[0]=='a':args.append(f[2]);f=f[1]
        args.reverse()
        return '(napps '+pp(f,known)+' ['+'; '.join(pp(a,known) for a in args)+'])'
    binder='NPi' if tag=='p' else 'NLam'
    return '('+binder+f' {t[1]} '+pp(t[2],known)+' '+pp(t[3],known)+')'

def emit(out:Path):
    import textwrap
    known={}
    chunks=[]
    def decl(name,t):
        raw=pp(t,known)
        body=textwrap.fill(raw,width=100,initial_indent='  ',subsequent_indent='  ',break_long_words=False,break_on_hyphens=False)
        chunks.append(f'Definition {name} : named :=\n{body}.\n')
        known[t]=name
    for name,t in CODE_DEFS:
        if name=='nEquality':
            chunks.append('(* The 8 data parameters followed by 23 individually guarded laws. *)')
            lines=[]
            for i,ty in params:
                lines.append('    ('+str(i)+', '+pp(ty,known)+')')
            for lname,i,ty in laws:
                lines.append('    (* '+lname+' *)\n    ('+str(i)+', '+pp(ty,known)+')')
            chunks.append('Definition observation_fields : list (nat * named) :=\n  [\n'+';\n'.join(lines)+'\n  ].\n')
            chunks.append('Definition nAllObs (body : named) : named := npis observation_fields body.\nDefinition nAbstractObs (body : named) : named := nlams observation_fields body.\n')
            known[('obs-marker',)]=True
        if name=='nJ9':
            for k in range(2,9): decl('nJ'+str(k),jf(k))
        decl(name,t)
    out.write_text('\n'.join(chunks))

def to_old(t,env=None,count=None):
    env=[] if env is None else env
    count=iter(range(10000000)) if count is None else count
    tag=t[0]
    if tag=='s':return ('s',t[1])
    if tag=='v':
        for a,b in env:
            if a==t[1]:return ('v',b)
        raise ValueError(f'Unbound name {t[1]}')
    if tag=='a':return ('a',to_old(t[1],env,count),to_old(t[2],env,count))
    s='x'+str(next(count))
    return (tag,s,to_old(t[2],env,count),to_old(t[3],[(t[1],s)]+env,count))

def run_checks(checker_path:Path,out:Path):
    spec=importlib.util.spec_from_file_location('checker',checker_path)
    ck=importlib.util.module_from_spec(spec);spec.loader.exec_module(ck)
    rows=[]
    for (name,t),expected in zip(CODE_DEFS,EXPECTED):
        assert not fv(t),(name,fv(t))
        a=to_old(t);e=to_old(expected)
        ck.check(a,e)
        rows.append({'definition':name,'scope':'closed','type_check':'passed'})
        print(name,'checked',flush=True)
        ck.clear_caches()
    for n in (0,1,2,4):
        case=L(20,D,ncase(n,V(20)))
        inv=L(20,D,ninv(n,V(20)))
        ck.check(to_old(case),to_old(ar(D,U(8))))
        ck.check(to_old(inv),to_old(ar(D,U(10))))
        rows.append({'case_and_invariant':n,'ranks':[8,10],'type_check':'passed'})
        ck.clear_caches()
    out.write_text(json.dumps({'status':'passed','verification':'Python beta-only PTS checker; NOT Rocq compilation','checks':rows},indent=2))

if __name__=='__main__':
    root=Path(__file__).resolve().parents[1]
    emit(root/'checks'/'generated_definitions.vpart')
    if '--check' in sys.argv:
        checker=root/'checks'/'pts_checker.py'
        run_checks(checker,root/'checks'/'object_code_checks.json')
