#!/usr/bin/env bash
# Publish this exact DirectR patch as a draft PR from akuklev/pts-rk.
# Requires GitHub CLI authenticated as akuklev, Git, Python 3, and network access.
# Does not force-push, update either main branch, merge, or request reviews.
set -euo pipefail

ROOT="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd)"
UPSTREAM='TurtlePU/pts-rk'
OWNER='akuklev'
FORK="${OWNER}/pts-rk"
BASE='723cf2ec61c737ae82ba33d2e7db44f650122b0e'
BRANCH="${DIRECT_R_BRANCH:-direct-r-interpretation-restructured}"

fail() { printf 'Error: %s\n' "$*" >&2; exit 1; }
usage() {
  cat <<'EOF'
Usage: bash publish.sh [--check-package | --help]

With no arguments: verify the package; require GitHub login akuklev; create
(or validate) akuklev/pts-rk; clone into a fresh temporary directory; apply
the three pinned patches on direct-r-interpretation-restructured; commit and push that branch;
then create a DRAFT pull request targeting TurtlePU/pts-rk:main.

--check-package performs only local checksum verification. No GitHub access.
The script does not compile Rocq. The PR explicitly states this limitation.
Set DIRECT_R_BRANCH to a different unused branch name when needed.
EOF
}
case "${1:-}" in
  --help|-h) usage; exit 0 ;;
  --check-package|'') ;;
  *) usage >&2; exit 2 ;;
esac
[[ $# -le 1 ]] || fail 'Unexpected extra arguments.'
command -v python3 >/dev/null || fail 'Python 3 is required.'
python3 - "$ROOT" <<'PY'
from pathlib import Path
import hashlib, json, sys
root = Path(sys.argv[1])
manifest = json.loads((root/'manifest.json').read_text())
for name, expected in manifest['sha256'].items():
    path = root/name
    if not path.is_file():
        raise SystemExit(f'Missing package file: {name}')
    actual = hashlib.sha256(path.read_bytes()).hexdigest()
    if actual != expected:
        raise SystemExit(f'Checksum mismatch: {name}; no publication performed.')
print(f"Verified {len(manifest['sha256'])} package files.")
PY
[[ "${1:-}" != '--check-package' ]] || exit 0

for command in gh git; do
  command -v "$command" >/dev/null || fail "Required command is unavailable: $command"
done
[[ "$BRANCH" != 'main' ]] || fail 'Refusing to publish on main.'
git check-ref-format --branch "$BRANCH" >/dev/null || fail 'Invalid branch name.'
export GH_HOST='github.com'
export GH_PROMPT_DISABLED='1'
gh auth status --hostname github.com >/dev/null || \
  fail 'Run gh auth login --hostname github.com and authenticate as akuklev.'
LOGIN="$(gh api --hostname github.com user --jq '.login')"
[[ "$LOGIN" == "$OWNER" ]] || \
  fail "Authenticated as $LOGIN, not $OWNER. No repositories were changed."
USER_ID="$(gh api --hostname github.com user --jq '.id')"
AUTHOR_NAME="$(gh api --hostname github.com user --jq '.name // .login')"
[[ "$USER_ID" =~ ^[0-9]+$ ]] || fail 'Unexpected GitHub user ID.'

WORK="$(mktemp -d "${TMPDIR:-/tmp}/pts-rk-direct-r.XXXXXX")"
printf 'Working directory: %s\n' "$WORK"
trap 'status=$?; if [ "$status" -ne 0 ]; then printf "Stopped without force-pushing or merging. Inspect retained files at: %s\n" "$WORK" >&2; fi' EXIT

# A pre-existing repository is reused only if it is the expected fork.
if gh api "repos/$FORK" >"$WORK/fork.json" 2>"$WORK/fork-lookup.log"; then
  printf 'Found existing repository %s; validating its parent.\n' "$FORK"
else
  if ! grep -q 'HTTP 404' "$WORK/fork-lookup.log"; then
    cat "$WORK/fork-lookup.log" >&2
    fail 'Could not determine whether the fork exists; no fork was requested.'
  fi
  gh repo fork "$UPSTREAM" --fork-name pts-rk \
    --default-branch-only --clone=false --remote=false
  ready=0
  for ((attempt=1; attempt<=30; attempt++)); do
    if gh api "repos/$FORK" >"$WORK/fork.json" 2>"$WORK/fork-lookup.log"; then
      ready=1
      break
    fi
    sleep 2
  done
  [[ "$ready" == 1 ]] || fail 'The fork is not yet readable; rerun later. No branch was pushed.'
fi
python3 - "$WORK/fork.json" "$UPSTREAM" "$FORK" <<'PY'
import json, sys
with open(sys.argv[1]) as f:
    repo = json.load(f)
if not (repo.get('fork') is True and
        repo.get('parent', {}).get('full_name') == sys.argv[2] and
        repo.get('full_name') == sys.argv[3]):
    raise SystemExit('Existing repository is not the expected fork; refusing to write.')
if repo.get('permissions', {}).get('push') is not True:
    raise SystemExit('The CLI account cannot push to the fork.')
PY

# Credentials come from gh only for these Git processes. No global Git
# configuration is changed and no token is printed or written into a remote URL.
git_auth() {
  git -c credential.helper= -c 'credential.helper=!gh auth git-credential' "$@"
}
git_auth clone --no-checkout "https://github.com/$FORK.git" "$WORK/repository"
cd "$WORK/repository"
git remote add upstream "https://github.com/$UPSTREAM.git"
git_auth fetch --no-tags upstream 'refs/heads/main:refs/remotes/upstream/main'
git cat-file -e "${BASE}^{commit}" || fail 'The pinned base commit was not fetched.'
git merge-base --is-ancestor "$BASE" refs/remotes/upstream/main || \
  fail 'The pinned base is not in upstream main history; manual review is required.'
CURRENT="$(git rev-parse refs/remotes/upstream/main)"
if [[ "$CURRENT" != "$BASE" ]]; then
  printf 'Notice: upstream has advanced. This draft remains based on the inspected commit %s.\n' "$BASE"
fi
HEADS="$(git_auth ls-remote --heads origin "refs/heads/$BRANCH")"
[[ -z "$HEADS" ]] || \
  fail "Remote branch $BRANCH already exists. Nothing was overwritten; choose DIRECT_R_BRANCH."
git switch --create "$BRANCH" "$BASE"
# The aggregate check detects conflicts before any commit is made.
git apply --check "$ROOT/direct-r.patch"
MESSAGES=(
  'Add draft native fuel-bounded PTS-rk checker and success proofs'
  'Split direct R interpretation codes, proofs, generators, and obligations'
  'Add separate regressions, build instructions, and DirectR provenance'
)
N=0
while IFS= read -r PATCH; do
  [[ -n "$PATCH" ]] || continue
  git apply --check "$ROOT/patches/$PATCH"
  git apply --index "$ROOT/patches/$PATCH"
  git diff --cached --check
  git -c user.name="$AUTHOR_NAME" \
      -c user.email="${USER_ID}+${LOGIN}@users.noreply.github.com" \
      commit -m "${MESSAGES[$N]}"
  N=$((N+1))
done < "$ROOT/patches/series.txt"
[[ "$N" == 3 ]] || fail 'Unexpected patch-series length.'
python3 - "$ROOT" <<'PYVERIFY'
from pathlib import Path
import hashlib, json, sys
manifest = json.loads((Path(sys.argv[1])/'manifest.json').read_text())
for name, expected in manifest['payload_sha256'].items():
    if hashlib.sha256(Path(name).read_bytes()).hexdigest() != expected:
        raise SystemExit('Patched file mismatch: ' + name)
print('All patched payload files match their checksums.')
PYVERIFY
git_auth push --set-upstream origin "refs/heads/$BRANCH:refs/heads/$BRANCH"
printf '\nRocq compilation was not performed; publishing as a draft.\n'
PR_URL="$(gh pr create --repo "$UPSTREAM" --base main \
  --head "$OWNER:$BRANCH" --draft --no-maintainer-edit \
  --title "$(cat "$ROOT/PR_TITLE.txt")" --body-file "$ROOT/PR_BODY.md")"
printf '\nFork: https://github.com/%s\nDraft pull request: %s\nLocal checkout: %s\n' \
  "$FORK" "$PR_URL" "$WORK/repository"
