# Original editable manuscript

PTS-rk.tex is the byte-for-byte original Markdown–TeX manuscript.
Its unmodified preamble, metadata class and custom Markdown runtime
are included here. To rebuild locally with LuaLaTeX, Biber and minted
(tested with TeX Live 2026), run:

    latexmk -lualatex -interaction=nonstopmode -halt-on-error PTS-rk.tex

PTS-rk_precompiled.tex is the pre-rendered XeLaTeX submission copy,
which uses the supplied frozen minted cache without shell execution.
PTS-rk_precompiled.bbl is the precompiled bibliography: no Biber run
is required for this submission entry point.
00README.json selects only that file for arXiv compilation; these
settings can instead be selected in arXiv's Review Files interface.
